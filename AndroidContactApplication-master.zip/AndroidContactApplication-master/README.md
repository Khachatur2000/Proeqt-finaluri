# AndroidContactApplication 

This is a Android Contact application and created by using Fragment , Recycle View and CardView .


### Inter Process :-

In this Application use one fragment for Recycle and caredview , second fragment use for imageView and details and last fragment use for add Contact details. 
then second and last Fragment is host by MainActivity and then use interface for communicate with each fragements.

How it look like,

![screenshot_1545371489](https://user-images.githubusercontent.com/31344335/50393404-1586b680-077c-11e9-8fe5-c5733cedbca8.png)




Before add number,


![screenshot_1545371527](https://user-images.githubusercontent.com/31344335/50393450-5252ad80-077c-11e9-96f2-10b132519c5b.png)



After added number,


![screenshot_1545371556](https://user-images.githubusercontent.com/31344335/50393479-78784d80-077c-11e9-8224-d706cba2955c.png)

